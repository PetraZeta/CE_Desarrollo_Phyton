from setuptools import setup

setup(
    name="Tarea01",
    version="0.1",
    description="Tarea 01 de POO",
    author="Inés García Zapata",
    packages=["Ejercicio02"]
)