import csv
from collections import defaultdict


def recuento_actividades(lector):
    ddata = defaultdict(list, {"Yoga": [0, 0, 0], "HIIT": [0, 0, 0],
                               "Cardio": [0, 0, 0], "Strength": [0, 0, 0]})
    for fila in lector:
        actividad = fila["Workout_Type"]
        ddata[actividad][0] += 1
        if fila["Gender"] == "Female":
            ddata[actividad][1] += 1
        else:
            ddata[actividad][2] += 1
    return ddata


def recuento_actividades_json(ruta_archivo, ruta_json):

    try:
        with open(ruta_archivo, "r", encoding="utf-8") as archivo:
            lector = csv.DictReader(archivo)
            ddata = recuento_actividades(lector)
            print(ddata)

        with open(ruta_json, "w", encoding="utf-8") as archivo_json:
            archivo_json.write("{\n")
            for idx, (clave, valores) in enumerate(ddata.items()):
                valores_str = f"[ {valores[0]}, {valores[1]}, {valores[2]} ]"
                if idx < len(ddata) - 1:
                    archivo_json.write(f'    "{clave}": {valores_str},\n')
                else:
                    archivo_json.write(f'    "{clave}": {valores_str}\n')
            archivo_json.write("}\n")
        return True
    except FileNotFoundError:
        print("No se encontró el archivo")
        return False
    except Exception as e:
        print(e)
        return False


def actividad_genero_csv(ruta_archivo, ruta_csv, genero, actividad):
    try:
        filas_filtradas = []
        with open(ruta_archivo, "r", encoding="utf-8") as archivo:
            lector = csv.DictReader(archivo)      
            for fila in lector:
                if fila["Gender"] == genero \
                        and fila["Workout_Type"] == actividad:
                    filas_filtradas.append(
                        {
                            "Age": fila["Age"],
                            "Gender": fila["Gender"],
                            "Hours": fila["Session_Duration (hours)"],
                            "Activity": fila["Workout_Type"]
                        }
                    )
        with open(ruta_csv, "w", newline="", encoding="utf-8") as archivo_csv:
            fieldnames = ["Age", "Gender", "Hours", "Activity"]
            writer = csv.DictWriter(archivo_csv, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(filas_filtradas)
        return True
    except FileNotFoundError:
        print("No se encontró el archivo")
        return False
    except Exception as e:
        print(e)
        return False